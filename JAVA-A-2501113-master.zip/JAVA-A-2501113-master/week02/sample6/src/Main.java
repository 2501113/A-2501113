import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);
        String name "";
        int age = 0;
        char gender = ' ';
        char result = ' ';

        System.out.print(" 당신의 이름은 ? ");
        name = keyboard.nextLine();
        System.out.printf(" %s님의 나이는 ? ", name);
        age = keyboard.nextInt();
        System.out.print("%s님의 성별 (남 = M, 여 = F)", name, age);
        gender = keyboard.next().charAt(0);

        re

        System.out.print("\n%s님의 나이는 %d살 입니다.\n", name, age);
        System.out.printf(" %s님의 성별은 %c(%c자) 입니다.\n ", name);
        temp = keyboard.nextInt( );
    }
    }