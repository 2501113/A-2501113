import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);
        String name= "";

        System.out.print("whats your name stranger !? ");
        name = keyboard.nextLine();







        System.out.println("이름 : " + name);




    }
}