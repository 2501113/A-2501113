//TIP 코드를 <b>실행</b>하려면 <shortcut actionId="Run"/>을(를) 누르거나
// 에디터 여백에 있는 <icon src="AllIcons.Actions.Execute"/> 아이콘을 클릭하세요.
public class Main {
    public static void main(String[] args) {
        byte a;
        short b;
        int c;
        long d;


        float f;
        double k;

        char ch;
        final float PI = 3.141592f;


        PI = 3.14f;


        a = (byte) 128;
        b = (short) 32768;
        c = (int) 3L;
        d = 3;

        f = 31.4f;
        k = 34.1;

        ch = 'A';


        String name = "A";
        String test = new String("test");






    }
}